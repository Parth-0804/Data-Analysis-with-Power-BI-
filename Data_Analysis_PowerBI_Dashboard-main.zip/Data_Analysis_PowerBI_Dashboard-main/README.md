# Data_Analysis_PowerBI_Dashboard
With the assistance of SQL file of the sales data, the Power BI dashboard will show the actual facts and figures of the business after the processes of Extract, Transform and Loading(ETL Process) and data Pipeline construction. 
![PowerBI_Dashboard_page-0001](https://user-images.githubusercontent.com/70774888/155896180-5d18a3f5-27a5-430d-9b8e-8f26a66590ac.jpg)
![PowerBI_Dashboard_page-0002](https://user-images.githubusercontent.com/70774888/155896187-4ec68ef5-4a72-449c-be96-9bfa58fbdf37.jpg)
