SELECT user()
